package src.java.vrt;

public class CarritoConverter extends _CarritoConverter {

}